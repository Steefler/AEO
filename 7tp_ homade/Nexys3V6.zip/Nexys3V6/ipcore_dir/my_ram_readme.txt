The following files were generated for 'my_ram' in directory 
C:\Users\jld\TP_AEV_2015\lastzip\nexys3V6.12.4\ipcore_dir\

dist_mem_gen_ds322.pdf:
   Please see the core data sheet.

dist_mem_gen_readme.txt:
   Text file indicating the files generated and how they are used.

my_ram.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

my_ram.gise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

my_ram.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

my_ram.sym:
   Please see the core data sheet.

my_ram.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

my_ram.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

my_ram.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

my_ram.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

my_ram.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

my_ram.xise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

my_ram_readme.txt:
   Text file indicating the files generated and how they are used.

my_ram_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

my_ram_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

